export  class  Policy {
    id: number;
    number:  number;
    amount:  number;
}