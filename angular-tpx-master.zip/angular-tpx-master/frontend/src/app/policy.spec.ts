import { Policy } from './policy';

describe('Policy', () => {
  it('should create an instance', () => {
    expect(new Policy()).toBeTruthy();
  });
});
